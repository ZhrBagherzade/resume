﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.WebService.Dto
{
    public class GetDictionary
    {
        public int? Id { get; set; }
        public string Name { get; set; }
    }
}
