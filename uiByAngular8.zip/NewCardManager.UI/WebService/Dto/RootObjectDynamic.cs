﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.WebService.Dto
{
    public class RootObjectDynamic<T>
    {
        public List<T> Result { get; set; }
        public string Script { get; set; }
        public string Html { get; set; }
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public string Exception { get; set; }
        
    }
}
