﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace NewCardManager.UI.WebService.Dto
{
    public class CallGetWebServiceResult
    {
        public HttpStatusCode HttpStatus { get; set; }
        public string result { get; set; }
    }

}
