﻿using NewCardManager.UI.WebService.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace NewCardManager.UI.WebService
{
    public interface IWebServiceRepository
    {
        HttpStatusCode CallWebService<T>(string Uri, string JsonData, out List<T> output);
        CallGetWebServiceResult CallGetWebService(string Uri, string JsonData);
        CallGetWebServiceResult CallPostWebService(string Uri, string JsonData, bool flg = false, string ControllerName = "", string ActionName = "", string param = "");
        List<GetDictionary> GetMcList();
        List<GetDictionary> GetDegreeList();
    }
}
