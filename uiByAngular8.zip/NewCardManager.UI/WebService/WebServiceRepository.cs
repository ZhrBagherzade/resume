﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using NewCardManager.UI.Common;
using NewCardManager.UI.WebService.Dto;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace NewCardManager.UI.WebService
{
    public class WebServiceRepository : IWebServiceRepository
    {
        private IConfiguration _configuration;
        private IMemoryCache _cache;
        private string Ip;
        private string Port;
        private string http = "https";
        public WebServiceRepository(IConfiguration configuration, IMemoryCache cach)
        {
            _configuration = configuration;
            Ip = _configuration.GetValue<string>("IpWebService");
            Port = _configuration.GetValue<string>("PortWebService");
            _cache = cach;
        }
        public HttpStatusCode CallWebService<T>(string Uri, string JsonData, out List<T> output)
        {

            output = null;
            using (var client = new HttpClient())
            {
                var buffer = System.Text.Encoding.UTF8.GetBytes(JsonData);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                var response = client.PostAsync(Uri, byteContent).Result;
                if (response.StatusCode == HttpStatusCode.OK)
                {

                    var result = response.Content.ReadAsStringAsync().Result;
                    RootObjectDynamic<T> model = JsonConvert.DeserializeObject<RootObjectDynamic<T>>(result);
                    output = model.Result;

                }

                return response.StatusCode;


            }
        }


        public CallGetWebServiceResult CallGetWebService(string Uri, string JsonData)
        {
            CallGetWebServiceResult output = new CallGetWebServiceResult();
            //output = null;
            using (var client = new HttpClient())
            {
                var buffer = System.Text.Encoding.UTF8.GetBytes(JsonData);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                var response = client.GetAsync(Uri).Result;
                output.HttpStatus = response.StatusCode;
                if (response.StatusCode == HttpStatusCode.OK)
                {

                    var result = response.Content.ReadAsStringAsync().Result;
                    output.result = result;
                    //RootObjectDynamic<T> model = JsonConvert.DeserializeObject<RootObjectDynamic<T>>(result);
                    //output = model.result;

                }


                return output;

            }
        }

        public CallGetWebServiceResult CallPostWebService(string Uri, string JsonData, bool flg = false, string ControllerName = "", string ActionName = "", string param = "")
        {
            Uri = flg ? $"{http}://{Ip}:{Port}/api/{ControllerName}/{ActionName}/{ param}" : Uri;
            CallGetWebServiceResult output = new CallGetWebServiceResult();
            try
            {
                //output = null;
                using (var client = new HttpClient())
                {
                    var buffer = System.Text.Encoding.UTF8.GetBytes(JsonData);
                    var byteContent = new ByteArrayContent(buffer);
                    byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    var response = client.PostAsync(Uri, byteContent).Result;
                    output.HttpStatus = response.StatusCode;
                    if (response.StatusCode == HttpStatusCode.OK)
                    {

                        var result = response.Content.ReadAsStringAsync().Result;
                        output.result = result;

                    }


                    return output;

                }
            }
            catch (Exception ex)
            {
                return new CallGetWebServiceResult { HttpStatus = HttpStatusCode.InternalServerError, result = "" };
            }
        }
        public List<GetDictionary> GetMcList()
        {
            List<GetDictionary> cacheEntry;
            if (!_cache.TryGetValue(ChacheKeies.MCListDictionary, out cacheEntry) || cacheEntry==null)
            {
                //CommonTools

                var result = CallPostWebService("", "", true, "CommonTools", "GetMcList", "");

                cacheEntry = JsonConvert.DeserializeObject<List<GetDictionary>>(result.result);
                    
                _cache.Set(ChacheKeies.MCListDictionary, cacheEntry);

            }
            return cacheEntry;
        }

        public List<GetDictionary> GetDegreeList()
        {
            List<GetDictionary> cacheEntry;
            if (!_cache.TryGetValue(ChacheKeies.DegreeListDictionary, out cacheEntry) || cacheEntry == null)
            {
                //CommonTools

                var result = CallPostWebService("", "", true, "CommonTools", "GetDegreeList", "");

                cacheEntry = JsonConvert.DeserializeObject<List<GetDictionary>>(result.result);

                _cache.Set(ChacheKeies.DegreeListDictionary, cacheEntry);

            }
            return cacheEntry;
        }

    }
}
