import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IssuanceRequestComponent } from './IssuanceRequest/issuanceRequest.component';

const routes: Routes = [
  {
    path: '',
    children: [
       
      {
        path: 'IssuanceRequest',
        component: IssuanceRequestComponent,
        data: {
         title: 'Issuance Request'
        }
      },
      
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FullRequestsRoutingModule { }
