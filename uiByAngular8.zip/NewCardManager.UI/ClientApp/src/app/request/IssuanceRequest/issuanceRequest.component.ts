﻿import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, NgForm } from '@angular/forms';


import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ImageService } from '../../shared/services/image.service';

import { Router, ActivatedRoute } from "@angular/router";
import { NgSelectModule, NgOption } from '@ng-select/ng-select';
import { IssuanceRequestApiService } from './IssuanceRequest-api-service';

class ImageSnippet {
    pending: boolean = false;
    status: string = 'init';
    constructor(public src: string, public file: File) { }
}
@Component({
    selector: 'app-issuanceRequest',
    templateUrl: './issuanceRequest.component.html',
    styleUrls: ['./issuanceRequest.component.scss']
})
export class IssuanceRequestComponent implements OnInit {
    MCList: any = [{ id: 1, name: "test1" }, { id: 66, name: "test2" }];
    DegreeList: any = [{ id: 1, name: "test3" }, { id: 99, name: "test4" }];
    image: any;
    userInterface: any = {
        firstName: "",
        lastName: "",
        firstNameEn: "",
        lastNameEn: "",
        nzamCode: "",
        nzamCodeEn: "",
        nzamCity: "",
        //nzamCityEn: "",
        spyName: "",
        spyNameEn: "",
        descriptionCode: "",
        f: true,
        hasimage: false,
        img: "",
        nationalityCode: "",
        inclusiveCode: ""

    };
    reqInterface: any = {
        reqId: 0,
        isShow: true,
        reqStts: 0,
        reqStatus: "",
        paymentStts: 0,
        paymentStatus: "",
        Description: "",
        insDStr: "",
        prc: 10000
    };

    isDisabled: boolean = true;
    selectedFile: ImageSnippet;
    //Variable Declaration
    currentPage: string = "About"
    title: string;

    confirm: boolean = false;
 

    constructor(private router: Router,
        private route: ActivatedRoute, private apiService: IssuanceRequestApiService, private modalService: NgbModal, private imageService: ImageService) {
        this.reqInterface = {
            reqId: 0,
            isShow: true,
            reqStts: 0,
            reqStatus: "",
            paymentStts: 0,
            paymentStatus: "",
            Description: "",
            insDStr: "",
            prc: 10000
        };
        this.userInterface = {
            firstName: "",
            lastName: "",
            firstNameEn: "",
            lastNameEn: "",
            nzamCode: "",
            nzamCodeEn: "",
            nzamCity: "",
            //nzamCityEn: "",
            spyName: "",
            spyNameEn: "",
            descriptionCode: "",
            f: true,
            hasimage: false,
            img: "",
            nationalityCode: "",
            inclusiveCode: ""

        };


    }
    ngOnInit(): void {


        this.GetActiveRequestCard();
        this.GetUserInterface();
        this.GetMcList();
        this.GetDegreeList();
    }
    GetMcList() {
        
        this.apiService.GetMcList().subscribe((data) => {
            //console.log(data);

            //this.router.navigateByUrl('/desk', { relativeTo: this.route.parent, skipLocationChange: true });
            if (data != null) {
                this.MCList = data;
            }
            else {
                this.MCList = [{ id: 1, name: "test1" }, { id: 66, name: "test2" }];
            }

        });

    }
    GetDegreeList() {
        
        this.apiService.GetDegreeList().subscribe((data) => {
            //console.log(data);

            //this.router.navigateByUrl('/desk', { relativeTo: this.route.parent, skipLocationChange: true });
            if (data != null) {
                this.DegreeList = data;
            }
            else {
                this.DegreeList = [{ id: 1, name: "test3" }, { id: 99, name: "test4" }];
            }

        });

    }
    //RefreshIssuanceRequestPaymentStts
    ChangeIssuanceRequestStts(stts: any) {
        if (stts <= this.reqInterface.reqStts) {
            return;
        }
        let input: any = {
            reqId: this.reqInterface.reqId,
            ShNezam: "test",
            reqStts: stts
        };
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }
        this.apiService.ChangeIssuanceRequestStts(input).subscribe((data) => {
            //console.log(data);

            //this.router.navigateByUrl('/desk', { relativeTo: this.route.parent, skipLocationChange: true });
            if (data != null) {
                output = data;
                if (output.code == "0")
                    this.reqInterface = output.result;

            }

        });

    }
    RefreshIssuanceRequestPaymentStts() {
        let input: any = {
            reqId: this.reqInterface.reqId,
            ShNezam: "test"
        };
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }
        this.apiService.RefreshIssuanceRequestPaymentStts(input).subscribe((data) => {

            if (data != null) {
                output = data;
                if (output.code == "0")
                    this.reqInterface = output.result;

            }

        });

    }
    GetActiveRequestCard() {
        var input: any;
        input = {
            shNezam: "test"
        };

        this.apiService.GetActiveRequestCard(input).subscribe((data) => {
            //console.log(data);

            //this.router.navigateByUrl('/desk', { relativeTo: this.route.parent, skipLocationChange: true });
            if (data != null) {
                this.reqInterface = data;
                console.log(data);
                if (!this.reqInterface.isShow) {
                    this.router.navigateByUrl('/desk', { relativeTo: this.route.parent, skipLocationChange: true });
                }
            }

        });
    }

    GetUserInterface() {
        var input: any;
        input = {
            shNezam: "test"
        };
        this.apiService.GetUserInterface(input).subscribe((data) => {
            this.userInterface = data;


        });
    }
    SavePrsnInterface() {
        this.userInterface.shNezam = "test";
        this.apiService.SavePrsnInterface(this.userInterface).subscribe((data) => {
            console.log(this.userInterface);

            //if (data != null) {
            //    this.userInterface = data;
            //}

        });
    }
    SaveIssuanceRequestInterface() {
        //this.userInterface.shNezam = "test";
        var input: any = {
            shNezam: "test"
        };
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }

        this.apiService.SaveIssuanceRequestInterface(input).subscribe((data) => {
            //console.log(data);
            if (data != null) {
                output = data;
                if (output.code == "0")
                    this.reqInterface = output.result;
            }
            //نمایش خطا
        });
    }
    private onSuccess() {
        this.selectedFile.pending = false;
        this.selectedFile.status = 'ok';
    }

    private onError() {
        this.selectedFile.pending = false;
        this.selectedFile.status = 'fail';
        this.selectedFile.src = '';
    }

    processFile(imageInput: any) {
        const file1: File = imageInput.files[0];
        const reader = new FileReader();

        reader.addEventListener('load', (event: any) => {

            var input: any = {
                shNezam: "test",
                file: event.target.result,
                fileType: 1
            };
            this.selectedFile = new ImageSnippet(event.target.result, file1);
            this.userInterface.img = event.target.result;
            this.selectedFile.pending = true;
            this.imageService.uploadImage(input, "Desk/UploadFile/").subscribe(

                (res) => {
                    //if (res.code == "0") {
                    //    this.GetUserInterface();
                    //}
                    //console.log(res);
                    this.onSuccess();
                },
                (err) => {
                    //console.log(err);
                    this.onError();
                });
        });

        reader.readAsDataURL(file1);
    }
    GetDetails(content, titleText) {

        this.title = titleText;
        this.modalService.open(content, { size: 'lg' }).result.then((result) => {
        }, (reason) => {
        });
    }

}
