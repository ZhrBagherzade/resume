﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GlobalConstants } from 'app/shared/constant/global-constants';

@Injectable({
    providedIn: 'root'
})
export class IssuanceRequestApiService {
    ControllerNm: string = "IssuanceRequest";
    constructor(private httpClient: HttpClient) { }
    public GetUserInterface(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/GetPrsnInterface/", input);
    }
    public SavePrsnInterface(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/SavePrsnInterface/", input);
    }
    public GetActiveRequestCard(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/GetActiveRequestCard/", input);
    }
    public SaveIssuanceRequestInterface(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/SaveIssuanceRequestInterface/", input);
    }
    public ChangeIssuanceRequestStts(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/ChangeIssuanceRequestStts/", input);
    }
    public RefreshIssuanceRequestPaymentStts(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/RefreshIssuanceRequestPaymentStts/", input);
    }
    public GetMcList() {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/GetMcList/", "");
    }
    public GetDegreeList() {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/GetDegreeList/", "");
    }
}

