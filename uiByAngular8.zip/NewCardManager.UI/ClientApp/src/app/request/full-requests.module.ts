import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule } from '@angular/forms';

import { ChartistModule} from 'ng-chartist';
import { AgmCoreModule } from '@agm/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FullRequestsRoutingModule } from './full-requests-routing.module';
import { IssuanceRequestComponent } from './IssuanceRequest/issuanceRequest.component';

import { QuillModule } from 'ngx-quill'
import { DragulaModule } from 'ng2-dragula';

import { CustomFormsModule } from 'ng2-validation';
import { MatchHeightModule } from "../shared/directives/match-height.directive";
import { ArchwizardModule } from 'angular-archwizard';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
    imports: [
        CommonModule,
        FullRequestsRoutingModule,
        FormsModule,
        ChartistModule,
        AgmCoreModule,
        NgbModule,
        CustomFormsModule,
        MatchHeightModule,
        ArchwizardModule,
        NgSelectModule, QuillModule, DragulaModule

    ],
    declarations: [       
        IssuanceRequestComponent
    ]
})
export class FullRequestsModule { }
