﻿import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DeskRoutingModule } from "app/desk/desk-routing.module";
import { ChartistModule } from 'ng-chartist';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatchHeightModule } from "../shared/directives/match-height.directive";
import { DeskComponent } from "app/desk/desk.component";
//import { FormOfRequestComponent } from './formOfRequest/formOfRequest.component';


@NgModule({
    imports: [
        FormsModule, ReactiveFormsModule,
        CommonModule,
        DeskRoutingModule,
        ChartistModule,
        NgbModule,
        MatchHeightModule
    ],
    exports: [],
    declarations: [
        DeskComponent//,
        //FormOfRequestComponent,
    ],
    providers: [],
})
export class DeskModule { }
