﻿import { Component, OnInit } from '@angular/core';
import { DeskApiService} from 'app/desk/desk-api-service';
import { GetUserInterfaceInput } from 'app/desk/desk-dto';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ImageService } from '../shared/services/image.service';

class ImageSnippet {
    pending: boolean = false;
    status: string = 'init';
    constructor(public src: string, public file: File) { }
}

@Component({
    selector: 'app-desk',
    templateUrl: './desk.component.html',
    styleUrls: ['./desk.component.scss']
})

export class DeskComponent implements OnInit {

    image: any;
    userInterface: any = {
        firstName: "",
        lastName: "",
        firstNameEn: "",
        lastNameEn: "",
        nzamCode: "",
        nzamCodeEn: "",
        nzamCity: "",
        //nzamCityEn: "",
        spyName: "",
        spyNameEn: "",
        descriptionCode: "",
        f: true,
        hasimage: false,
        img: "",
        nationalityCode: "",
        inclusiveCode:""

    };
    //modalContent: any = {
    //    title = "",
    //    content="",

    //}
    selectedFile: ImageSnippet;
    //Variable Declaration
    currentPage: string = "About"
    title: string;
    confirm: boolean=false;
    constructor(private apiService: DeskApiService, private modalService: NgbModal, private imageService: ImageService) { }
    ngOnInit(): void {
        this.GetUserInterface();
    }



    GetUserInterface() {
        var input: any;
        input = {
            shNezam: "test"
        };
        this.apiService.GetUserInterface(input).subscribe((data) => {
            //console.log(data);
            if (data != null) {
                this.userInterface = data;
            }

        });
    }
    private onSuccess() {
        this.selectedFile.pending = false;
        this.selectedFile.status = 'ok';
    }

    private onError() {
        this.selectedFile.pending = false;
        this.selectedFile.status = 'fail';
        this.selectedFile.src = '';
    }

    processFile(imageInput: any) {
        const file1: File = imageInput.files[0];
        const reader = new FileReader();

        reader.addEventListener('load', (event: any) => {
            
            var input: any = {
                shNezam:"test",
                file: event.target.result,
                fileType: 1
            };
            this.selectedFile = new ImageSnippet(event.target.result, file1);
            this.userInterface.img = event.target.result;
            this.selectedFile.pending = true;
            this.imageService.uploadImage(input, "Desk/UploadFile/").subscribe(
               
                (res) => {
                    //if (res.code == "0") {
                    //    this.GetUserInterface();
                    //}
                    //console.log(res);
                    this.onSuccess();
                },
                (err) => {
                    //console.log(err);
                    this.onError();
                });
        });

        reader.readAsDataURL(file1);
    }
    GetDetails(content, titleText) {
        
        this.title = titleText;
        this.modalService.open(content, { size: 'lg' }).result.then((result) => {
        }, (reason) => {
        });
    }



}