﻿import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class GetUserInterfaceInput {
    userName: string;
}
export class GetUserInterfaceReturn {
    name: string;
    familyName: string;
    nzamCode: string;
    nzamCity: string;
    spyName: string;
    isDescriptionCode: string;
    F: string;
    hasimage: string;
}