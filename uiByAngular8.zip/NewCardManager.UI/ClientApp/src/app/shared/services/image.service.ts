﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GlobalConstants } from 'app/shared/constant/global-constants';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ImageService {

    constructor(private http: HttpClient) { }


    public uploadImage(input:any, uri: string = ""): Observable<any> {
        //const formData = new FormData();

        //formData.append('image', image);
        console.log(GlobalConstants.apiURL + uri);
        console.log(input);
        return this.http.post(GlobalConstants.apiURL +uri, input);
    }
}