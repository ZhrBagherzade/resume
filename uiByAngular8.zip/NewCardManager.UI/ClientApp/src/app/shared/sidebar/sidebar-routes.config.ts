﻿import { RouteInfo } from './sidebar.metadata';

//Sidebar menu Routes and data
export const ROUTES: RouteInfo[] = [
    { path: '/desk', title: 'Desk', icon: 'ft-home', class: '', badge: '', badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1', isExternalLink: false, submenu: [] }
    
    ,
    {
        path: '', title: 'Request', icon: 'ft-credit-card', class: 'has-sub', badge: '', badgeClass: '', isExternalLink: false,
        submenu: [
            { path: '/request/IssuanceRequest', title: 'Issuance Request', icon: 'ft-file-plus', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: [] },
 
        ]
    }
    , { path: '/IssuanceCenter', title: 'IssuanceCenter', icon: 'ft-package', class: '', badge: '', badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1', isExternalLink: false, submenu: [] }
    , { path: '/PrinterCenter', title: 'PrinterCenter', icon: 'icon-printer', class: '', badge: '', badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1', isExternalLink: false, submenu: [] }
];
