﻿export class GlobalConstants {
    public static apiURL: string = "/api/";

    public static siteTitle: string = "myTest";
}