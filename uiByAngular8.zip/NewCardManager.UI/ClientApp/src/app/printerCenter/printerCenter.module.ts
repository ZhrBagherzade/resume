﻿import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ChartistModule } from 'ng-chartist';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatchHeightModule } from "../shared/directives/match-height.directive";
import { PrinterCenterComponent, NgbdModalContent } from './printerCenter.component';
//import { NgPersianDatepickerModule } from 'ng-persian-datepicker';
import { DpDatePickerModule } from 'ng2-jalali-date-picker';
import { PrinterCenterRoutingModule } from './printerCenter-routing.module';
//import { FormOfRequestComponent } from './formOfRequest/formOfRequest.component';
import { NgSelectModule } from '@ng-select/ng-select';

import { QuillModule } from 'ngx-quill'
import { DragulaModule } from 'ng2-dragula';

@NgModule({
    imports: [
        FormsModule, ReactiveFormsModule,
        CommonModule,
        PrinterCenterRoutingModule,
        ChartistModule,
        NgbModule,
        MatchHeightModule,
        DpDatePickerModule,
        NgSelectModule,
        QuillModule,
        DragulaModule],
    exports: [],
    declarations: [
        PrinterCenterComponent,
        NgbdModalContent//,
        //FormOfRequestComponent,
    ],
    
    entryComponents: [NgbdModalContent],
    providers: []
   
})
export class PrinterCenterModule { }
