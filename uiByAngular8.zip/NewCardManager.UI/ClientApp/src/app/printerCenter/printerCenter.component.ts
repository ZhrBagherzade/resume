﻿import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PrinterCenterApiService } from './printerCenter-api-service';
import {ViewEncapsulation, Input } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
    selector: 'ngbd-modal-content',
    template: `
 <div class="card">
    <div class="card-header bg-info">
        <h4 class="card-title white">کنترل اطلاعات</h4>
        <button type="button" class="close white" aria-label="Close" (click)="activeModal.dismiss('Cross click')">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="card-body" >
      
    </div>
    
     
    <div class="card-footer">
        <button type="button" class="btn btn-raised btn-danger" (click)="IssuanceCenterUnCnf(param)"><span class="ft-x-circle"></span>عدم تایید</button>
        <button type="button" class="btn btn-raised btn-warning" (click)="IssuanceCenterControl(param)"><span class="ft-camera"></span>کنترل</button>
        <button type="button" (click)="IssuanceCenterCnfInfoSendToPrintCenter(param);" class="btn btn-raised btn-success"><span class="ft-check-circle"></span>تایید و ارسال به مرکز چاپ</button>
        <!--<button type="button" class="btn btn-danger btn-raised" (click)="activeModal.dismiss('Cross click')">بستن</button>-->

    </div>
    </div>

  `
})

export class NgbdModalContent {
    @Input() param;
    constructor(public activeModal: NgbActiveModal,private apiService: PrinterCenterApiService,) { }
    

}


@Component({
    selector: 'app-printerCenter',
    templateUrl: './printerCenter.component.html'
})

export class PrinterCenterComponent implements OnInit {
    reqList: any = [];
    ctrlInfo: any = [];
    requestStatus: any = [
        {
            id: 1,
            name: "test"
        },
        {
            id: 2,
            name:  "test2"
        }
    ];
    MCList: any = [//az getmclist
        {
            id: 3,
            name: "test3"
        },
        {
            id: 4,
            name: "test4"
        }
    ];
    users: any = [//hanuz neveshte nashode
        {
            id: 5,
            name: "test5"
        },
        {
            id: 6,
            name: "test6"
        }
    ];
    req: any = {
        fromD: "",
        toD: "",
        usrId: 0,
        nzamCode: "0",
        nzamCityId: 0,
        stts: 4

    };
    toUsrId: any = 0;

    constructor(private router: Router,
        private route: ActivatedRoute, private apiService: PrinterCenterApiService, private modalService: NgbModal) {
    }
    ngOnInit(): void {
        this.GetMcList();
    }
    GetMcList() {

        this.apiService.GetMcList().subscribe((data) => {
            //console.log(data);

            //this.router.navigateByUrl('/desk', { relativeTo: this.route.parent, skipLocationChange: true });
            if (data != null) {
                this.MCList = data;
            }
            else {
                this.MCList = [{ id: 1, name: "test1" }, { id: 66, name: "test2" }];
            }

        });

    }
    GetPrinterRequest() {
        
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }
        this.apiService.GetPrinterRequest(this.req).subscribe((data) => {
            if (data != null) {
                output = data;
                this.reqList = output.result;
            }
        });
    }
    openContent(param:any) {
        const modalRef = this.modalService.open(NgbdModalContent);
        modalRef.componentInstance.param = param;
    }
   
    PrinterCenterWatch(dto:any) {
        let input: any = {
            reqId: dto.reqId
            //,
            //stts: 5
        }
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }//نمایش خطا ها
        this.apiService.PrinterCenterWatch(input).subscribe((data) => {
            if (data != null) {
                output = data;
                if (output.code == "0")
                    this.GetPrinterRequest();
               
            }
        });
    }
    
   PrinterCenterRequestAssignTo() {
        let input: any = {
            reqList: this.reqList,
            userId: this.toUsrId,
            userAssignBy :1
            
        }
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }//نمایش خطا ها
        this.apiService.PrinterCenterRequestAssignTo(input).subscribe((data) => {
            if (data != null) {
                output = data;
                if (output.code == "0")
                    this.GetPrinterRequest();

            }
        });
    }
   
}