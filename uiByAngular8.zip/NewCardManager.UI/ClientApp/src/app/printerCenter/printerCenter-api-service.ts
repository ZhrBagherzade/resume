﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GlobalConstants } from 'app/shared/constant/global-constants';

@Injectable({
    providedIn: 'root'
})
export class PrinterCenterApiService {
    ControllerNm: string = "PrinterCartable";
    constructor(private httpClient: HttpClient) { }
    public GetPrinterRequest(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/GetPrinterRequest/", input);
    }
  
    public PrinterCenterWatch(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/PrinterCenterWatch/", input);
    }
    public PrinterCenterRequestAssignTo(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/PrinterCenterRequestAssignTo/", input);
    }
    public GetMcList() {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/GetMcList/", "");
    }
}

