﻿import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PrinterCenterComponent } from './printerCenter.component';

const routes: Routes = [
    {
        path: '',
        component: PrinterCenterComponent,
        data: {
            title: 'IssuanceCenter'
        },
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class PrinterCenterRoutingModule { }