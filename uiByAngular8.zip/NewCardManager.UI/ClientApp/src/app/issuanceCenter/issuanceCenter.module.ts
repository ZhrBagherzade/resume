﻿import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ChartistModule } from 'ng-chartist';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatchHeightModule } from "../shared/directives/match-height.directive";
import { IssuanceCenterComponent, NgbdModalContent } from './issuanceCenter.component';
//import { NgPersianDatepickerModule } from 'ng-persian-datepicker';
import { DpDatePickerModule } from 'ng2-jalali-date-picker';
import { IssuanceCenterRoutingModule } from './issuanceCenter-routing.module';
//import { FormOfRequestComponent } from './formOfRequest/formOfRequest.component';
import { NgSelectModule } from '@ng-select/ng-select';

import { QuillModule } from 'ngx-quill'
import { DragulaModule } from 'ng2-dragula';

@NgModule({
    imports: [
        FormsModule, ReactiveFormsModule,
        CommonModule,
        IssuanceCenterRoutingModule,
        ChartistModule,
        NgbModule,
        MatchHeightModule,
        DpDatePickerModule,
        NgSelectModule,
        QuillModule,
        DragulaModule],
    exports: [],
    declarations: [
        IssuanceCenterComponent,
        NgbdModalContent//,
        //FormOfRequestComponent,
    ],
    
    entryComponents: [NgbdModalContent],
    providers: []
   
})
export class IssuanceCenterModule { }
