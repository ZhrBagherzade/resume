﻿import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IssuanceCenterApiService } from './issuanceCenter-api-service';
import {ViewEncapsulation, Input } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
    selector: 'ngbd-modal-content',
    template: `

    <div class="modal-header bg-info">
        <h4 class="modal-title white">کنترل اطلاعات</h4>
        <button type="button" class="close white" aria-label="Close" (click)="activeModal.dismiss('Cross click')">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body" id="kbModal-body">
       <div class="row">
       <div class="col-md-6">
        <table class="table table-responsive-sm table-sm">
            <thead>
                <tr>
                    <th>عنوان</th>
                    <th>اطلاعات کاربر</th>
                    <th>اطلاعات سامانه</th>
                    <th>تایید</th>
                </tr>
            </thead>
            <tbody>
                <tr *ngFor="let r of param.ctrlInfo.controlDatas">
                    <td>{{r.title}}</td>
                    <td><span *ngIf="r.key !='Photo'">{{r.infoFromDb}}</span>
                        <img *ngIf="r.key =='Photo'" alt="Card image cap" class="card-img-top"  [src]="r.infoFromDb" style="width:100px;" />
                    </td>
                    <td><span *ngIf="r.key !='Photo'">{{r.infoFromWs}}</span>
                        <img *ngIf="r.key =='Photo'" alt="Card image cap" class="card-img-top"  [src]="r.infoFromWs" style="width:100px;" />
                    </td>
                    <th><input type="checkbox" aria-label="Checkbox for following text input" [(ngModel)]="r.cnf"></th>
                </tr>
            </tbody>
        </table>
    </div>
<div class="col-md-6">
        <table class="table table-responsive-sm table-sm">
            <thead>
                <tr>
                    <th>عنوان</th>
                    <th>اطلاعات کاربر</th>
                    <th>اطلاعات سامانه</th>
                    <th>تایید</th>
                </tr>
            </thead>
            <tbody>
                <tr *ngFor="let r of param.ctrlInfo.controlDatas2">
                    <td>{{r.title}}</td>
                    <td><span *ngIf="r.key !='Photo'">{{r.infoFromDb}}</span>
                        <img *ngIf="r.key =='Photo'" alt="Card image cap" class="card-img-top"  [src]="r.infoFromDb" style="width:100px;" />
                    </td>
                    <td><span *ngIf="r.key !='Photo'">{{r.infoFromWs}}</span>
                        <img *ngIf="r.key =='Photo'" alt="Card image cap" class="card-img-top"  [src]="r.infoFromWs" style="width:100px;" />
                    </td>
                    <th><input type="checkbox" aria-label="Checkbox for following text input" [(ngModel)]="r.cnf"></th>
                </tr>
            </tbody>
        </table>
    </div>
    </div>
    </div>
     
    <div class="modal-footer">
        <button type="button" class="btn btn-raised btn-danger" (click)="IssuanceCenterUnCnf(param)"><span class="ft-x-circle"></span>عدم تایید</button>
        <button type="button" class="btn btn-raised btn-warning" (click)="IssuanceCenterControl(param)"><span class="ft-camera"></span>کنترل</button>
        <button type="button" (click)="IssuanceCenterCnfInfoSendToPrintCenter(param);" class="btn btn-raised btn-success"><span class="ft-check-circle"></span>تایید و ارسال به مرکز چاپ</button>
        <!--<button type="button" class="btn btn-danger btn-raised" (click)="activeModal.dismiss('Cross click')">بستن</button>-->

    </div>
    

  `
})

export class NgbdModalContent {
    @Input() param;
    constructor(public activeModal: NgbActiveModal,private apiService: IssuanceCenterApiService,) { }
    IssuanceCenterCnfInfoSendToPrintCenter(param:any) {
        let input = {
            reqId: param.reqId,
            userName: param.userName,
            controlData: param.ctrlInfo
        }
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }//نمایش خطا ها
        this.apiService.IssuanceCenterCnfInfoSendToPrintCenter(input).subscribe((data) => {
            if (data != null) {
                output = data;

            }
        });
    }

    IssuanceCenterControl(cntrlDto: any, usrName: any, rId: any) {
        let input = {
            reqId: rId,
            userName: usrName,
            controlData: cntrlDto
        }
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }//نمایش خطا ها
        //
        this.apiService.IssuanceCenterControl(input).subscribe((data) => {
            if (data != null) {
                output = data;

            }
        });
    }

    //IssuanceCenterUnCnf(cntrlDto: any, usrName: any, rId: any) {


    //}

}


@Component({
    selector: 'app-issuanceCenter',
    templateUrl: './issuanceCenter.component.html',
    styleUrls: ['./issuanceCenter.component.scss']
})

export class IssuanceCenterComponent implements OnInit {
    reqList: any = [];
    ctrlInfo: any = [];
    requestStatus: any = [
        {
            id: 1,
            name: "test"
        },
        {
            id: 2,
            name:  "test2"
        }
    ];
    MCList: any = [//az getmclist
        {
            id: 3,
            name: "test3"
        },
        {
            id: 4,
            name: "test4"
        }
    ];
    users: any = [//hanuz neveshte nashode
        {
            id: 5,
            name: "test5"
        },
        {
            id: 6,
            name: "test6"
        }
    ];
    req: any = {
        fromD: "",
        toD: "",
        usrId: 0,
        nzamCode: "0",
        nzamCityId: 0,
        stts: 4

    };
    toUsrId: any = 0;

    constructor(private router: Router,
        private route: ActivatedRoute, private apiService: IssuanceCenterApiService, private modalService: NgbModal) {
    }
    ngOnInit(): void {
        this.GetMcList();
    }
    GetMcList() {

        this.apiService.GetMcList().subscribe((data) => {
            //console.log(data);

            //this.router.navigateByUrl('/desk', { relativeTo: this.route.parent, skipLocationChange: true });
            if (data != null) {
                this.MCList = data;
            }
            else {
                this.MCList = [{ id: 1, name: "test1" }, { id: 66, name: "test2" }];
            }

        });

    }
    GetIssuanceRequest() {
        
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }
        this.apiService.GetIssuanceRequest(this.req).subscribe((data) => {
            if (data != null) {
                output = data;
                this.reqList = output.result;
            }
        });
    }
    openContent(param:any) {
        const modalRef = this.modalService.open(NgbdModalContent);
        modalRef.componentInstance.param = param;
    }
    IssuanceCenterGetCntrlInfo(dto:any) {
        let input: any = {
            shNezam :dto.shNezam
        }
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {
                controlDatas: [],
                controlDatas2: [],
                getInfoFromWS: {}
            }
        }//نمایش خطا ها


        this.apiService.IssuanceCenterGetCntrlInfo(input).subscribe((data) => {
            if (data != null) {
                output = data;
                console.log(output);
                this.ctrlInfo = output.result;

                let content = {
                    ctrlInfo: this.ctrlInfo,
                    reqId: dto.reqId,
                    shNezam: dto.shNezam,//shomare nezam pezeshk
                    userName: "test"//karbar login konande ast
                };
                console.log(content);
                this.openContent(content);
                //this.modalService.open(
                //    content
                //    , { size: 'lg' }).result.then((result) => {
                //    }, (reason) => {

                //    });
            }
        });
    }

    IssuanceCenterWatch(dto:any) {
        let input: any = {
            reqId: dto.reqId
            //,
            //stts: 5
        }
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }//نمایش خطا ها
        this.apiService.IssuanceCenterWatch(input).subscribe((data) => {
            if (data != null) {
                output = data;
                if (output.code == "0")
                    this.GetIssuanceRequest();
               
            }
        });
    }
    
    IssuanceCenterRequestAssignTo() {
        let input: any = {
            reqList: this.reqList,
            userId: this.toUsrId,
            userAssignBy :1
            
        }
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }//نمایش خطا ها
        this.apiService.IssuanceCenterRequestAssignTo(input).subscribe((data) => {
            if (data != null) {
                output = data;
                if (output.code == "0")
                    this.GetIssuanceRequest();

            }
        });
    }
    IssuanceCenterControl(cntrlDto: any, usrName: any, rId: any) {
        let input = {
            reqId: rId,
            userName: usrName,
            controlData: cntrlDto
        }
        let output: any = {
            code: "0",
            message: "با موفقیت انجام شد",
            ex: "",
            result: {}
        }//نمایش خطا ها
        //
        this.apiService.IssuanceCenterControl(input).subscribe((data) => {
            if (data != null) {
                output = data;

            }
        });
    }
}