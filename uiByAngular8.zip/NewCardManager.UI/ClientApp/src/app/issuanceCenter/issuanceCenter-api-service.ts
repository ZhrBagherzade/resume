﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GlobalConstants } from 'app/shared/constant/global-constants';

@Injectable({
    providedIn: 'root'
})
export class IssuanceCenterApiService {
    ControllerNm: string = "IssuanceCartable";
    constructor(private httpClient: HttpClient) { }
    public GetIssuanceRequest(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/GetIssuanceRequest/", input);
    }
    public IssuanceCenterGetCntrlInfo(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/IssuanceCenterGetCntrlInfo/", input);
    }
    public IssuanceCenterWatch(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/IssuanceCenterWatch/", input);
    }
    public IssuanceCenterCnfInfoSendToPrintCenter(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/IssuanceCenterCnfInfoSendToPrintCenter/", input);
    }
    public IssuanceCenterControl(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/IssuanceCenterControl/", input);
    }
    public IssuanceCenterRequestAssignTo(input: any) {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/IssuanceCenterRequestAssignTo/", input);
    }
    public GetMcList() {
        return this.httpClient.post(GlobalConstants.apiURL + this.ControllerNm + "/GetMcList/", "");
    }
}

