﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewCardManager.UI.Common
{
    public class Result<T>
    {
        public string Code { get; set; } = "0";
        public string Message { get; set; } = "با موفقیت انجام شد";
        public string Ex { get; set; } = "";
        public T result { get; set; }
    }
}
