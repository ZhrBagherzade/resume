﻿using NewCardManager.UI.WebService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewCardManager.UI.Common
{
    public class CommonToolsService:ICommonToolsService
    {
        private readonly IWebServiceRepository _webServiceRepository;

        public CommonToolsService(IWebServiceRepository webServiceRepository)
        {
            _webServiceRepository = webServiceRepository;
        }
    }
}
