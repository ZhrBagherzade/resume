﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SpaServices.Prerendering;
using NewCardManager.UI.Common;
using NewCardManager.UI.Controller.IssuanceRequest.Dto;
using NewCardManager.UI.WebService;
using NewCardManager.UI.WebService.Dto;
using Newtonsoft.Json;

namespace NewCardManager.UI.Controller.IssuanceRequest
{
    [Route("api/[controller]/[action]/{input?}")]
    [ApiController]
    public class IssuanceRequestController : ControllerBase
    {
        private readonly IWebServiceRepository _webServiceRepository;
        public IssuanceRequestController(IWebServiceRepository webServiceRepository)
        {
            _webServiceRepository = webServiceRepository;
        }

        //Bagherzadeh: واکشی اطلاعات از سامانه
        [HttpPost]

        //واکشی اطلاعات از دیتابیس

        public GetPrsnInterfaceReturn GetPrsnInterface(GetPrsnInterfaceInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerRequest", "GetPrsnInterface", "");
                var prsnInfo = JsonConvert.DeserializeObject<GetPrsnInterfaceReturn>(result.result);
                return prsnInfo;
            }
            catch (Exception ex)
            {
                return new GetPrsnInterfaceReturn
                {
                    Sex = "F",
                    //F = true,
                    LastName = "تستی",
                    LastNameEn = "Testi",
                    //hasimage = false,
                    DescriptionCode = "DescriptionCode",
                    FirstName = "تست",
                    FirstNameEn = "Test",
                    nzamCity = "تهران",
                    //nzamCityEn = "تهران",
                    nzamCode = "123321",
                    nzamCodeEn = "1254587eee",
                    spyName = "تخصص",
                   // spyNameEn = "spy",
                    InclusiveCode = "eee11100rrr",
                    NationalityCode = "0011223344"

                };
            }
        }
        public UploadFileReturn UploadFile (UploadFileInput input)
        {
            var json = JsonConvert.SerializeObject(input);
            var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerRequest", "UploadFile", "");
            var ret = JsonConvert.DeserializeObject<UploadFileReturn>(result.result);
            return ret;
        }

        public List<GetDictionary> GetMcList() => _webServiceRepository.GetMcList();
        public List<GetDictionary> GetDegreeList() => _webServiceRepository.GetDegreeList();

        public SavePrsnInterfaceReturn SavePrsnInterface(SavePrsnInterfaceInput input)
        {
            var json = JsonConvert.SerializeObject(input);
            var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerRequest", "SavePrsnInterface", "");
            var ret = JsonConvert.DeserializeObject<SavePrsnInterfaceReturn>(result.result);
            return ret;
        }

        public GetActiveRequestCardReturn GetActiveRequestCard(GetActiveRequestCardInput input)
        {
            var json = JsonConvert.SerializeObject(input);
            var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerRequest", "GetActiveRequestCard", "");
            if (result.HttpStatus == System.Net.HttpStatusCode.OK)
            {
                var ret = JsonConvert.DeserializeObject<GetActiveRequestCardReturn>(result.result);
                return ret;
            }
            return null;
            
        }
        public Result<SaveIssuanceRequestInterfaceReturn> SaveIssuanceRequestInterface(SaveIssuanceRequestInterfaceInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerRequest", "SaveIssuanceRequestInterface", "");
                if (result.HttpStatus == System.Net.HttpStatusCode.OK)
                {
                    var ret = JsonConvert.DeserializeObject<Result<SaveIssuanceRequestInterfaceReturn>>(result.result);
                    return ret;
                }
                return new Result<SaveIssuanceRequestInterfaceReturn>
                {
                    Code = "103",
                    Message = "خطای سرویس",
                    
                };
            }
            catch(Exception ex)
            {
                return new Result<SaveIssuanceRequestInterfaceReturn>
                {
                    Code = "104",
                    Message = "خطای اتصال",
                    Ex = ex.Message
                };
            }
        }
        public Result<ChangeIssuanceRequestSttsReturn> ChangeIssuanceRequestStts(ChangeIssuanceRequestSttsInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerRequest", "ChangeIssuanceRequestStts", "");
                if (result.HttpStatus == System.Net.HttpStatusCode.OK)
                {
                    var ret = JsonConvert.DeserializeObject<Result<ChangeIssuanceRequestSttsReturn>>(result.result);
                    return ret;
                }
                return new Result<ChangeIssuanceRequestSttsReturn>
                {
                    Code = "108",
                    Message = "خطای سرویس",

                };
            }
            catch (Exception ex)
            {
                return new Result<ChangeIssuanceRequestSttsReturn>
                {
                    Code = "109",
                    Message = "خطای اتصال",
                    Ex = ex.Message
                };
            }
        }
        [HttpPost]
        public Result<RefreshIssuanceRequestPaymentSttsReturn> RefreshIssuanceRequestPaymentStts(RefreshIssuanceRequestPaymentSttsInput input)
        {
            throw new NotImplementedException();
        }

    }
}
