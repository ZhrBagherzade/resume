﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewCardManager.UI.Controller.IssuanceRequest.Dto
{
    public class UploadFileReturn
    {
        public string Code { get; set; } = "0";
        public string errorMessage { get; set; } = "ذخیره با موفقیت انجام شد";
        public string ex { get; set; }
    }
}
