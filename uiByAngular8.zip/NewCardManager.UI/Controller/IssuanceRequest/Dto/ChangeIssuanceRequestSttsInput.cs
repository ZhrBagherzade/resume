﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.Controller.IssuanceRequest.Dto
{
    public class ChangeIssuanceRequestSttsInput
    {
        public int reqId { get; set; }
        public string ShNezam { get; set; }
        public int reqStts { get; set; }
    }
}
