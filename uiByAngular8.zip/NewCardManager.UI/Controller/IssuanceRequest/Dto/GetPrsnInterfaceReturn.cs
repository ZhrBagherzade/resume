﻿using System;
using System.Reflection.Metadata.Ecma335;

namespace NewCardManager.UI.Controller.IssuanceRequest
{
    public class GetPrsnInterfaceReturn
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FirstNameEn { get; set; }
        public string LastNameEn { get; set; }
        public string nzamCode { get; set; }
        public string nzamCodeEn { get; set; }
        public string nzamCity { get; set; }
        public int nzamCityId { get; set; }
        public string spyName { get; set; }
        public int spyId { get; set; }
        public string DescriptionCode { get; set; }
        public string NationalityCode { get; set; }
        public string InclusiveCode { get; set; }
        public DateTime? expD { get; set; }
        public string Sex { get; set; }
        public bool F => Sex == "F";
        public bool hasimage => !string.IsNullOrEmpty(img) && !string.IsNullOrWhiteSpace(img);
        public string img { get; set; }
    }
}