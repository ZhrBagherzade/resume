﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewCardManager.UI.Controller.IssuanceRequest.Dto
{
    public class GetActiveRequestCardReturn
    {
        public int reqId { get; set; }
        public int reqStts { get; set; }
        public string reqStatus { get; set; }
        public int paymentStts { get; set; }
        public string paymentStatus { get; set; }
        public string Description { get; set; }
        public DateTime insD { get; set; }
        public string insDStr { get; set; }
        public bool isShow { get; set; }
        public int Prc { get; set; }
    }
}
