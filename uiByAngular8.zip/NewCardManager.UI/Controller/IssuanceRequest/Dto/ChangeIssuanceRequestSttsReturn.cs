﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.Controller.IssuanceRequest.Dto
{
    public class ChangeIssuanceRequestSttsReturn
    {
        public int reqId { get; set; }
        public int reqStts { get; set; }
        public string reqStatus { get; set; }
        public int paymentStts { get; set; }
        public string paymentStatus { get; set; }
        public string Description { get; set; }
        public DateTime insD { get; set; }
        public DateTime? PayD { get; set; }
        public string insDStr { get; set; }
        public string payDStr
        { get; set; }
        public bool isShow { get; set; }
        public int Prc { get; set; }
    }
}
