﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.Controller.IssuanceRequest
{
    public class SavePrsnInterfaceReturn
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public string ex { get; set; }
    }
}
