﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NewCardManager.UI.Controller.IssuanceRequest.Dto
{
    public class UploadFileInput
    {
        public string ShNezam { get; set; }
        public string file { get; set; }
        public int fileType { get; set; }
    }
}
