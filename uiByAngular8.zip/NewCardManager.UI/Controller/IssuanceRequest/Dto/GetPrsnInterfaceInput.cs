﻿namespace NewCardManager.UI.Controller.IssuanceRequest
{
    public class GetPrsnInterfaceInput
    {
        public string ShNezam { get; set; }
    }
}