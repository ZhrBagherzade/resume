﻿using NewCardManager.UI.Controller.IssuanceRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.Controller.IssuanceCartable.Dto
{
    public class IssuanceCenterGetCntrlInfoReturn
    {
        public List<ControlData> ControlDatas { get; set; }
        public List<ControlData> ControlDatas2 { get; set; }
        public GetPrsnInterfaceReturn getInfoFromWS { get; set; }
    }

    public class ControlData
    {
        public string key { get; set; }
        public string title { get; set; }
        public string infoFromDb { get; set; }
        public string infoFromWs { get; set; }
        public bool cnf { get; set; } 
    }
}
