﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewCardManager.UI.Controller.IssuanceCartable.Dto
{
    public class GetIssuanceRequestInput
    {
        public string ShNezam { get; set; }
        public int? NzamCityId { get; set; }
        public string NzamCode { get; set; }
        public int? UsrId { get; set; }
        public int? stts { get; set; }
        public string fromD { get; set; }
        public string toD { get; set; }
    }
}
