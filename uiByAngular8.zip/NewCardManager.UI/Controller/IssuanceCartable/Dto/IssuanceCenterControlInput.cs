﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.Controller.IssuanceCartable.Dto
{
    public class IssuanceCenterControlInput
    {
        public IssuanceCenterGetCntrlInfoReturn ControlData { get; set; }
        public int reqId { get; set; }
        public string userName { get; set; }
    }
}
