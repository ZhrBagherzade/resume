﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.Controller.IssuanceCartable.Dto
{
    public class IssuanceCenterGetCntrlInfoInput
    {
        public string ShNezam { get; set; }
    }
}
