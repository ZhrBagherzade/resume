﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewCardManager.UI.Controller.IssuanceCartable.Dto
{
    public class GetIssuanceRequestReturn
    {
        public bool isSelected { get; set; }
        public int reqId { get; set; }
        public int rdf { get; set; }
        public string fnm { get; set; }
        public string fnmEn { get; set; }
        public string lnm { get; set; }
        public string lnmEn { get; set; }
        public string ShNezam { get; set; }
        public string nzamCode { get; set; }
        public string nzamCity { get; set; }
        public int nzamCityId { get; set; }
        public string userNm { get; set; }
        public int userId { get; set; }
        public string inclusiveCode { get; set; }
        public string ntlId { get; set; }
        public string reqStatus { get; set; }
        public bool isWatch { get; set; }
        public int reqStts { get; set; }
    }
}
