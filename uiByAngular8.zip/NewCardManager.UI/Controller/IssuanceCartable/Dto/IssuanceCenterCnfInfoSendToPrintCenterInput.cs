﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.Controller.IssuanceCartable.Dto
{
    public class IssuanceCenterCnfInfoSendToPrintCenterInput
    {
        public IssuanceCenterGetCntrlInfoForInsertReturn ControlData { get; set; }
        public int reqId { get; set; }
        public string ShNezam { get; set; }
        public string userName { get; set; }
    }

    public class IssuanceCenterGetCntrlInfoForInsertReturn
    {
        public List<ControlForInsertData> ControlDatas { get; set; }
        public List<ControlForInsertData> ControlDatas2 { get; set; }
    }

    public class ControlForInsertData
    {
        public string key { get; set; }
        public string title { get; set; }
        public bool cnf { get; set; }
    }
}
