﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewCardManager.UI.Controller.IssuanceCartable.Dto
{
    public class IssuanceCenterRequestAssignToInput
    {
        public List<IssuanceRequestList> reqList { get; set; }
        public int UserId { get; set; }
        public int userAssignBy { get; set; }
    }

    public class IssuanceRequestList
    {
        public bool isSelected { get; set; }
        public int reqId { get; set; }
    }
}
