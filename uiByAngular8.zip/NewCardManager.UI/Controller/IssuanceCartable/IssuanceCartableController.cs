﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewCardManager.UI.Common;
using NewCardManager.UI.Controller.IssuanceCartable.Dto;
using NewCardManager.UI.WebService;
using NewCardManager.UI.WebService.Dto;
using Newtonsoft.Json;

namespace NewCardManager.UI.Controller.IssuanceCartable
{
    [Route("api/[controller]/[action]/{input?}")]
    [ApiController]
    public class IssuanceCartableController : ControllerBase
    {
        private readonly IWebServiceRepository _webServiceRepository;
        public IssuanceCartableController(IWebServiceRepository webServiceRepository)
        {
            _webServiceRepository = webServiceRepository;
        }
        //خطا ها باید در یک repository قرار بگیرند که مشخص باشد
        [HttpPost]
        public Result<List<GetIssuanceRequestReturn>> GetIssuanceRequest(GetIssuanceRequestInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerIssuanceCenter", "IssuanceCenterGetIssuanceRequest", "");
                if (result.HttpStatus == System.Net.HttpStatusCode.OK)
                {
                    var ret = JsonConvert.DeserializeObject<Result<List<GetIssuanceRequestReturn>>>(result.result);
                    return ret;
                }
                return new Result<List<GetIssuanceRequestReturn>>
                {
                    Code = "110",
                    Message = "خطای سرویس",

                };
            }
            catch (Exception ex)
            {
                return new Result<List<GetIssuanceRequestReturn>>
                {
                    Code = "111",
                    Message = "خطای اتصال",
                    Ex = ex.Message
                };
            }
        }

        [HttpPost]
        public Result<bool> IssuanceCenterRequestAssignTo(IssuanceCenterRequestAssignToInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerIssuanceCenter", "IssuanceCenterRequestAssignTo", "");
                if (result.HttpStatus == System.Net.HttpStatusCode.OK)
                {
                    var ret = JsonConvert.DeserializeObject<Result<bool>>(result.result);
                    return ret;
                }
                return new Result<bool>
                {
                    Code = "110",
                    Message = "خطای سرویس",

                };
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Code = "111",
                    Message = "خطای اتصال",
                    Ex = ex.Message,
                    result = false
                };
            }
        }
        [HttpPost]
        public Result<bool> IssuanceCenterUnCnf(IssuanceCenterControlInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerIssuanceCenter", "IssuanceCenterUnCnf", "");
                if (result.HttpStatus == System.Net.HttpStatusCode.OK)
                {
                    var ret = JsonConvert.DeserializeObject<Result<bool>>(result.result);
                    return ret;
                }
                return new Result<bool>
                {
                    Code = "110",
                    Message = "خطای سرویس",

                };
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Code = "111",
                    Message = "خطای اتصال",
                    Ex = ex.Message,
                    result = false
                };
            }
        }
        [HttpPost]
        public Result<bool> IssuanceCenterControl(IssuanceCenterControlInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerIssuanceCenter", "IssuanceCenterControl", "");
                if (result.HttpStatus == System.Net.HttpStatusCode.OK)
                {
                    var ret = JsonConvert.DeserializeObject<Result<bool>>(result.result);
                    return ret;
                }
                return new Result<bool>
                {
                    Code = "110",
                    Message = "خطای سرویس",

                };
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Code = "111",
                    Message = "خطای اتصال",
                    Ex = ex.Message,
                    result = false
                };
            }
        }
        [HttpPost]
        public Result<bool> IssuanceCenterWatch(IssuanceCenterWatchInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerIssuanceCenter", "IssuanceCenterWatch", "");
                if (result.HttpStatus == System.Net.HttpStatusCode.OK)
                {
                    var ret = JsonConvert.DeserializeObject<Result<bool>>(result.result);
                    return ret;
                }
                return new Result<bool>
                {
                    Code = "110",
                    Message = "خطای سرویس",

                };
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Code = "111",
                    Message = "خطای اتصال",
                    Ex = ex.Message,
                    result = false
                };
            }
        }
        [HttpPost]
        public Result<IssuanceCenterGetCntrlInfoReturn> IssuanceCenterGetCntrlInfo(IssuanceCenterGetCntrlInfoInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerIssuanceCenter", "IssuanceCenterGetCntrlInfo", "");
                if (result.HttpStatus == System.Net.HttpStatusCode.OK)
                {
                    var ret = JsonConvert.DeserializeObject<Result<IssuanceCenterGetCntrlInfoReturn>>(result.result);
                    return ret;
                }
                return new Result<IssuanceCenterGetCntrlInfoReturn>
                {
                    Code = "110",
                    Message = "خطای سرویس",

                };
            }
            catch (Exception ex)
            {
                return new Result<IssuanceCenterGetCntrlInfoReturn>
                {
                    Code = "111",
                    Message = "خطای اتصال",
                    Ex = ex.Message
                };
            }
        }
        [HttpPost]
        public Result<bool> IssuanceCenterCnfInfoSendToPrintCenter(IssuanceCenterCnfInfoSendToPrintCenterInput input)
        {
            try
            {
                var json = JsonConvert.SerializeObject(input);
                var result = _webServiceRepository.CallPostWebService("", json, true, "CardManagerIssuanceCenter", "IssuanceCenterCnfInfoSendToPrintCenter", "");
                if (result.HttpStatus == System.Net.HttpStatusCode.OK)
                {
                    var ret = JsonConvert.DeserializeObject<Result<bool>>(result.result);
                    return ret;
                }
                return new Result<bool>
                {
                    Code = "110",
                    Message = "خطای سرویس",

                };
            }
            catch (Exception ex)
            {
                return new Result<bool>
                {
                    Code = "111",
                    Message = "خطای اتصال",
                    Ex = ex.Message,
                    result = false
                };
            }
        }
        [HttpPost]
        public List<GetDictionary> GetMcList() => _webServiceRepository.GetMcList();
        [HttpPost]
        public List<GetDictionary> GetDegreeList() => _webServiceRepository.GetDegreeList();
    }
}
