﻿(function () {
    var controllerId = 'app.views.recommenderSystem.recommenderSystem';
    angular.module('app').controller(controllerId, [
        '$rootScope', '$state', 'appSession', '$stateParams', 'abp.services.app.recommenderSystem',
        function ($rootScope, $state, appSession, $stateParams, recommenderSystemService) {
            var vm = this;
            vm.parameters = {
                name: $stateParams.name,
                url: $stateParams.url
            };

            vm.condition = {
                fromPrice: 0,
                toPrice: 0,
                minPrice: 0,
                maxPrice: 0,
                attr: [],
                name: '',
                groupProduct: vm.parameters
            };
            function firstLoad() {
                recommenderSystemService.getProduct({
                    groupProduct: vm.parameters
                }).then(function (result) {

                    vm.products = result.data.products;
                    vm.attributs = result.data.attributes;
                    vm.condition.fromPrice = result.data.minPrice;
                    vm.condition.toPrice = result.data.maxPrice;
                    vm.condition.minPrice = result.data.minPrice;
                    vm.condition.maxPrice = result.data.maxPrice;
                });
            }
            firstLoad();
            vm.getProductsWithConditions = function () {
                vm.condition.attr = vm.attributs;
                recommenderSystemService.getProductsWithConditions(vm.condition)
                    .then(function (result) {
                    vm.products = result.data;
                });
            }
            vm.goToProductsEvaluation = function (product) {
                $stateParams = {
                    url1: product.url,
                    name1: product.name,
                    groupProduct1: vm.parameters,
                    jsonProduct1: product.jsonProduct,
                    price1: product.price
                };
                $state.transitionTo('productsEvaluation', $stateParams, {
                    reload: true, inherit: false, notify: true
                });
            }
            vm.clearFilter = function () {
                firstLoad();
            }
        }
    ]);
})();