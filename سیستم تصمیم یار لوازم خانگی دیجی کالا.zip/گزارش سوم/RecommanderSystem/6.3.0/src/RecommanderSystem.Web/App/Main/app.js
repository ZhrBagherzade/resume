﻿(function () {
    'use strict';

    var app = angular.module('app', [
        'ngAnimate',
        'ngSanitize',

        'ui.router',
        'ui.bootstrap',
        'ui.jq',

        'abp'
    ]);
    
    //Configuration for Angular UI routing.
    app.config([
        '$stateProvider', '$urlRouterProvider', '$locationProvider', '$qProvider',
        function ($stateProvider, $urlRouterProvider, $locationProvider, $qProvider) {
            $locationProvider.hashPrefix('');
            $urlRouterProvider.otherwise('/');
            $qProvider.errorOnUnhandledRejections(false);

            //if (abp.auth.hasPermission('Pages.Users')) {
            //    $stateProvider
            //        .state('users', {
            //            url: '/users',
            //            templateUrl: '/App/Main/views/users/index.cshtml',
            //            menu: 'Users' //Matches to name of 'Users' menu in RecommanderSystemNavigationProvider
            //        });
            //    $urlRouterProvider.otherwise('/users');
            //}

            //if (abp.auth.hasPermission('Pages.Roles')) {
            //    $stateProvider
            //        .state('roles', {
            //            url: '/roles',
            //            templateUrl: '/App/Main/views/roles/index.cshtml',
            //            menu: 'Roles' //Matches to name of 'Tenants' menu in RecommanderSystemNavigationProvider
            //        });
            //    $urlRouterProvider.otherwise('/roles');
            //}

            //if (abp.auth.hasPermission('Pages.Tenants')) {
            //    $stateProvider
            //        .state('tenants', {
            //            url: '/tenants',
            //            templateUrl: '/App/Main/views/tenants/index.cshtml',
            //            menu: 'Tenants' //Matches to name of 'Tenants' menu in RecommanderSystemNavigationProvider
            //        });
            //    $urlRouterProvider.otherwise('/tenants');
            //}

            $stateProvider
                .state('home', {
                    url: '/',
                    templateUrl: '/App/Main/views/home/home.cshtml',
                    menu: 'Home' //Matches to name of 'Home' menu in RecommanderSystemNavigationProvider
                })
                .state('about', {
                    url: '/about',
                    templateUrl: '/App/Main/views/about/about.cshtml',
                    menu: 'About' //Matches to name of 'About' menu in RecommanderSystemNavigationProvider
                })
                // route to show our basic form (/form)
                .state('recommenderSystem', {
                    url: '/recommenderSystem',
                    templateUrl: '/App/Main/views/recommenderSystem/recommenderSystem.html',
                    menu: 'recommenderSystem',
                    params: {
                        url: {
                            value: ''
                        },
                        name: {
                            value: ''
                        }
                    }
                }).state('productsEvaluation', {
                    url: '/productsEvaluation',
                    templateUrl: '/App/Main/views/recommenderSystem/productsEvaluation.html',
                    menu: 'productsEvaluation',
                    params: {
                        url1: {
                            value: ''
                        },
                        name1: {
                            value: ''
                        },
                        jsonProduct1: {
                            value: ''
                        },
                        price1: {
                            value: ''
                        },
                        groupProduct1: {
                            value: {}
                        },
                        
                    }
                });
            $urlRouterProvider.otherwise('/');
        }
    ]);

})();