﻿(function () {
    var controllerId = 'app.views.recommenderSystem.productsEvaluation';
    angular.module('app').controller(controllerId, [
        '$rootScope', '$state', 'appSession', '$stateParams', 'abp.services.app.recommenderSystem',
        function ($rootScope, $state, appSession, $stateParams, recommenderSystemService) {
            var vm = this;
            vm.parameters = $stateParams;
            vm.input = {
                url: vm.parameters.url1,
                price: vm.parameters.price1,
                jsonProduct: vm.parameters.jsonProduct1,
                name: vm.parameters.name1,
                groupProduct: vm.parameters.groupProduct1
            };

            function load() {
                //window.Morris.Donut({
                //    element: 'donut_chart',
                //    data: [{
                //        label: 'Chrome',
                //        value: 37
                //    }, {
                //        label: 'Firefox',
                //        value: 30
                //    }, {
                //        label: 'Safari',
                //        value: 18
                //    }, {
                //        label: 'Opera',
                //        value: 12
                //    }, {
                //        label: 'Other',
                //        value: 3
                //    }],
                //    colors: ['rgb(233, 30, 99)', 'rgb(0, 188, 212)', 'rgb(255, 152, 0)', 'rgb(0, 150, 136)', 'rgb(96, 125, 139)'],
                //    formatter: function (y) {
                //        return y + '%';
                //    }
                //});
                recommenderSystemService.analysisProducts(vm.input)
                    .then(function (result) {
                        vm.attrEvaluation = result.data.attrEvaluation;
                        vm.name = result.data.name;
                        vm.colors = result.data.colors;
                        vm.donutData = {};
                        var i = 0;
                        var chartData0 = {
                            element: 'chart_0',
                            data: vm.attrEvaluation[0].attrEvaluation
                        };
                        Morris.Donut(chartData0);
                        var chartData1 = {
                            element: 'chart_1',
                            data: vm.attrEvaluation[1].attrEvaluation
                        };
                        Morris.Donut(chartData1);
                        var chartData2 = {
                            element: 'chart_2',
                            data: vm.attrEvaluation[2].attrEvaluation
                        };
                        Morris.Donut(chartData2);
                        var chartData3 = {
                            element: 'chart_3',
                            data: vm.attrEvaluation[3].attrEvaluation
                        };
                        Morris.Donut(chartData3);
                        var chartData4 = {
                            element: 'chart_4',
                            data: vm.attrEvaluation[4].attrEvaluation
                        };
                        Morris.Donut(chartData4);
                        var chartData5 = {
                            element: 'chart_5',
                            data: vm.attrEvaluation[5].attrEvaluation
                        };
                        Morris.Donut(chartData5);
                        var chartData6 = {
                            element: 'chart_6',
                            data: vm.attrEvaluation[6].attrEvaluation
                        };
                        Morris.Donut(chartData6);
                        var chartData7 = {
                            element: 'chart_7',
                            data: vm.attrEvaluation[7].attrEvaluation
                        };
                        Morris.Donut(chartData7);
                        var chartData8 = {
                            element: 'chart_8',
                            data: vm.attrEvaluation[8].attrEvaluation
                        };
                        Morris.Donut(chartData8);
                        var chartData9 = {
                            element: 'chart_9',
                            data: vm.attrEvaluation[9].attrEvaluation
                        };
                        Morris.Donut(chartData9);

                        
                       
                    });
            }
            load();
        }
    ]);
})();