﻿(function () {
    var controllerId = 'app.views.layout.sidebarNav';
    angular.module('app').controller(controllerId, [
        '$rootScope', '$state', 'appSession', 'abp.services.app.menu', '$stateParams',
        function ($rootScope, $state, appSession, menuService, $stateParams) {
            var vm = this;
            vm.menuItems = [
                createMenuItem(App.localize("HomePage"), "", "home", "home", ""),
                //createMenuItem(App.localize("Tenants"), "Pages.Tenants", "business", "tenants", ""),
                //createMenuItem(App.localize("Users"), "Pages.Users", "people", "users", ""),
                //createMenuItem(App.localize("Roles"), "Pages.Roles", "local_offer", "roles", "")و
               
            ];
            function getMenu(){
                menuService.loadMenuService()
                    .then(function (result) {
                        
                        
                        vm.menuFromService = result.data;
                        angular.forEach(vm.menuFromService, function (res) {
                            let child = [];
                            angular.forEach(res.subMenus, function (res1) {
                                child.push(createMenuItem(res1.key, "", "business", "", "", res1.href));
                            });
                            vm.menuItems.push(createMenuItem(res.key, "", "business", "", child, ""));
                        });
                    });

            }
            getMenu();

            vm.showMenuItem = function (menuItem) {
                if (menuItem.permissionName) {
                    return abp.auth.isGranted(menuItem.permissionName);
                }

                return true;
            }

            function createMenuItem(name, permissionName, icon, route, childItems, url) {
                
                return {
                    name: name,
                    permissionName: permissionName,
                    icon: icon,
                    route: route,
                    items: childItems,
                    href : url

                };
            }
            
            vm.goToRecommenderSystem = function (href, name1) {
                $stateParams = {
                    url: href,
                    name: name1
                };
                $state.transitionTo('recommenderSystem', $stateParams, {
                    reload: true, inherit: false, notify: true
                });
            }
        }
    ]);
})();