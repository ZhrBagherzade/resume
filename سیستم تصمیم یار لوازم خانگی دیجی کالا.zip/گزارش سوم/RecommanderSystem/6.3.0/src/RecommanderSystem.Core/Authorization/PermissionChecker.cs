﻿using Abp.Authorization;
using RecommanderSystem.Authorization.Roles;
using RecommanderSystem.Authorization.Users;

namespace RecommanderSystem.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {

        }
    }
}
