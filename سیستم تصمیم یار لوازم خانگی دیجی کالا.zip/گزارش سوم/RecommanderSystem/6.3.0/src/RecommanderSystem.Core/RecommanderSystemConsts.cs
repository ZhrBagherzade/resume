﻿namespace RecommanderSystem
{
    public class RecommanderSystemConsts
    {
        public const string LocalizationSourceName = "RecommanderSystem";

        public const bool MultiTenancyEnabled = true;
    }
}