﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.StaticValues
{
    public static class StaticValue
    {
        public static string path = @"D:\DigiKala\";
        public static string bazarURL = "https://www.digikala.com";
        public static Dictionary<string, Dictionary<string, string>> Menu;
        public static string toEnglishNumber(string input)
        {
            string EnglishNumbers = "";
            for (int i = 0; i < input.Length; i++)
            {
                if (Char.IsDigit(input[i]))
                {
                    EnglishNumbers += char.GetNumericValue(input, i);
                }
                else
                {
                    EnglishNumbers += input[i].ToString();
                }
            }
            return EnglishNumbers;
        }
        public class ParentDto
        {

            //{"id":2577917,"name":"یخچال و فریزر شارپ مدل SG-GC53","category":"یخچال و فریزر","brand":"Sharp","variant":9759898,"price":159000000,"quantity":0}
            public long Id { get; set; }
            public string name { get; set; }
            public string category { get; set; }
            public string brand { get; set; }
            public string variant { get; set; }
            public string price { get; set; }
            public string quantity { get; set; }
        }

    }
}
