﻿using HtmlAgilityPack;
using Newtonsoft.Json;
using RecommanderSystem.RecommederSystem.Dto;
using RecommanderSystem.StaticValues;
using ScrapySharp.Extensions;
using ScrapySharp.Network;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.RecommederSystem
{
    public class RecommenderSystemAppService : RecommanderSystemAppServiceBase, IRecommenderSystemAppService
    {
        private string getImportantAttr(string url, string name)
        {
            ScrapingBrowser Browser = new ScrapingBrowser();
            Browser.AllowAutoRedirect = true; // Browser has many settings you can access in setup
            Browser.AllowMetaRedirect = true;
            Browser.AutoDetectCharsetEncoding = false;
            Browser.Encoding = Encoding.UTF8;
            //go to the home page
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            WebPage PageResult = Browser.NavigateToPage(new Uri(url));
            List<HtmlNode> header = PageResult.Html.CssSelect(".c-box__header").ToList();
            Dictionary<string, string> attr = new Dictionary<string, string>();
            string[] notFeatures = new string[] { "دسته‌بندی نتایج".Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك"), "جستجو در نتایج:".Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك"), "فروشنده".Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك") };
            int i = 0;
            foreach (var feature in header)
            {

                string text = feature.InnerText.Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");
                if (!notFeatures.Contains(text))
                {
                    attr.Add($"attr{i}", text);
                    i++;
                }
            }

            System.Console.WriteLine(DateTime.Now);
            string jsonString = JsonConvert.SerializeObject(attr);

            // Write that JSON to txt file,  
            System.IO.File.WriteAllText(StaticValue.path + $"attr_{name}.json", jsonString);
            System.Console.WriteLine(DateTime.Now);
            return jsonString;
        }
        private List<GetAttributeValuesReturn> GetAttributeValues(GetAttributeValuesInput input)
        {
            List<GetAttributeValuesReturn> output = new List<GetAttributeValuesReturn>();


            string json = "";

            Dictionary<string, string> attr;

            if (File.Exists(StaticValue.path + $"attr_{input.name}.json"))
            {
                json = File.ReadAllText(StaticValue.path + $"attr_{input.name}.json");

            }
            else
            {
                json = getImportantAttr(StaticValue.bazarURL + input.url, input.name);
            }
            attr = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
            int i = 0;
            foreach (var itm in attr)
            {
                output.Add(new GetAttributeValuesReturn
                {
                    displayTitle = itm.Value,
                    mainTitle = $"i_{i}"
                });
                i++;
            }

            return output;
        }

        public ProductAndAttributes GetProduct(GetProductInput input)
        {
            List<List<GetProductReturn>> products = new List<List<GetProductReturn>>();
            ProductAndAttributes output = new ProductAndAttributes();
            List<Dictionary<string, string>> product;
            string json = GetProductFromFile(input);
            product = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(json);
            List<GetProductReturn> tempList = new List<GetProductReturn>();
            foreach (var itm in product)
            {
                if (!tempList.Any() || tempList.Count() < 4)
                {
                    tempList.Add(new GetProductReturn
                    {
                        jsonProduct = JsonConvert.SerializeObject(itm),
                        name = itm["عنوان"],
                        price = itm["قیمت"],
                        url = itm["url"]

                    });

                }
                else
                {
                    products.Add(tempList);
                    tempList = new List<GetProductReturn>();

                }

            }
            if (tempList.Any())
            {
                products.Add(tempList);
            }

            output.products = products;
            var attrs = GetAttributeValues(input.groupProduct);

            foreach (var itm in attrs)
            {
                itm.isPrice = false;
                if (itm.displayTitle.Contains("رنگ‌ها"))
                {
                    itm.displayTitle = "رنگ";
                }
                if (itm.displayTitle.Trim() == "محدوده قيمت مورد نظر")
                {
                    itm.isPrice = true;
                    var priceList = product.Select(x => long.Parse(x["قیمت"].Replace(",", ""))).ToList();
                    itm.minPrice = priceList.Min();
                    itm.maxPrice = priceList.Max();
                    output.minPrice = priceList.Min();
                    output.maxPrice = priceList.Max();


                }
                itm.value = new List<GetSubAttributeValuesReturn>();
                foreach (var s in product)
                {

                    s.TryGetValue(itm.displayTitle, out string value);
                    if (!string.IsNullOrEmpty(value))
                    {
                        var splitSubAttr = value.Split(',');
                        foreach (var v in splitSubAttr)
                        {
                            var lst = itm.value.Select(x => x.value.Trim()).ToList();
                            bool flg = !lst.Contains(v.Trim());
                            if (flg)
                                itm.value.Add(new GetSubAttributeValuesReturn
                                {
                                    name = v,
                                    value = v,
                                    selected = false
                                });

                        }
                    }
                }

            }
            output.attributes = attrs;
            return output;
        }

        private string GetProductFromFile(GetProductInput input)
        {
            string json = "";

            if (File.Exists(StaticValue.path + $"{input.groupProduct.name}.json"))
            {
                json = File.ReadAllText(StaticValue.path + $"{input.groupProduct.name}.json");

            }
            else
            {
                json = exploreData(StaticValue.bazarURL + input.groupProduct.url, input.groupProduct.name);
            }

            return json;
        }

        public List<List<GetProductReturn>> GetProductsWithConditions(GetProductInput input)
        {
            List<List<GetProductReturn>> products = new List<List<GetProductReturn>>();
            ProductAndAttributes output = new ProductAndAttributes();
            string json = "";

            List<Dictionary<string, string>> product;

            if (File.Exists(StaticValue.path + $"{input.groupProduct.name}.json"))
            {
                json = File.ReadAllText(StaticValue.path + $"{input.groupProduct.name}.json");

            }
            else
            {
                json = exploreData(StaticValue.bazarURL + input.groupProduct.url, input.groupProduct.name);
            }
            product = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(json);
            var productResult = new List<Dictionary<string, string>>();
            if (!string.IsNullOrWhiteSpace(input.name))
            {
                product = product.Where(p => p["عنوان"].Trim().Contains(input.name)).ToList();
            }
            if (!string.IsNullOrWhiteSpace(input.fromPrice))
            {
                product = product.Where(p => long.Parse(p["قیمت"].Replace(",", "")) >= long.Parse(input.fromPrice)).ToList();
            }
            if (!string.IsNullOrWhiteSpace(input.toPrice))
            {
                product = product.Where(p => long.Parse(p["قیمت"].Replace(",", "")) <= long.Parse(input.toPrice)).ToList();
            }

            foreach (var a in input.attr)
            {
                var values = a.value.Where(x => x.selected).Select(x => x.value.Trim()).ToList();
                List<Dictionary<string, string>> pTemp = new List<Dictionary<string, string>>();

                foreach (var v in values)
                {
                    pTemp = product.Where(p => 
                    (string.IsNullOrEmpty(p.TryGetValue((string.IsNullOrEmpty(a.displayTitle)?"": a.displayTitle).Trim(), out string val)? val: "")?"": p[(string.IsNullOrEmpty(a.displayTitle) ? "" : a.displayTitle).Trim()]).Trim().Contains(v.Trim())).ToList();
                    productResult.AddRange(pTemp);

                }
                if (values.Any())
                {
                    product = productResult;
                    productResult = new List<Dictionary<string, string>>();
                }


            }

            List<GetProductReturn> tempList = new List<GetProductReturn>();
            foreach (var itm in product)
            {
                if (!tempList.Any() || tempList.Count() < 4)
                {
                    tempList.Add(new GetProductReturn
                    {
                        jsonProduct = JsonConvert.SerializeObject(itm),
                        name = itm["عنوان"],
                        price = itm["قیمت"],
                        url = itm["url"]

                    });

                }
                else
                {
                    products.Add(tempList);
                    tempList = new List<GetProductReturn>();
                }

            }
            if (tempList.Any())
            {
                products.Add(tempList);
            }
            return products;
        }

        private string exploreData(string url, string name1)
        {

            // setup the browser
            ScrapingBrowser Browser = new ScrapingBrowser();
            Browser.AllowAutoRedirect = true; // Browser has many settings you can access in setup
            Browser.AllowMetaRedirect = true;
            Browser.AutoDetectCharsetEncoding = false;
            Browser.Encoding = Encoding.UTF8;
            //go to the home page
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            int max = 0;
            Dictionary<string, string> maxDic = new Dictionary<string, string>();

            Dictionary<string, string> pairs = new Dictionary<string, string>();

            Dictionary<string, string> dic;


            int i = 1;
            string uri = $"{url}?pageno={i}&sortby=4";
            WebPage PageResult = Browser.NavigateToPage(new Uri(uri));
            List<HtmlNode> aTags = PageResult.Html.CssSelect(".js-product-item").ToList();




            List<Dictionary<string, string>> product = new List<Dictionary<string, string>>();
            System.Console.WriteLine(DateTime.Now);
            while (aTags.Any())
            {

                foreach (var a in aTags)
                {
                    string json = a.ParentNode.Attributes.First(z => z.Name == "data-enhanced-ecommerce").Value;
                    StaticValue.ParentDto p = JsonConvert.DeserializeObject<StaticValue.ParentDto>(json);
                    var purePrice = int.TryParse(p.price, out int priceItem) ? priceItem : 0;
                    if (purePrice == 0)
                        break;

                    var href = a.Attributes.First(y => y.Name == "href").Value;
                    var name = StaticValue.bazarURL + href;

                    try
                    {

                        WebPage PageResult1 = Browser.NavigateToPage(new Uri(name));

                        var spanColor = PageResult1.Html.CssSelect(".c-tooltip--small-bottom").ToList();
                        string colors = string.Join(",", spanColor.Select(x => x.InnerText.Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك")));

                        dic = new Dictionary<string, string>();
                        string title = PageResult1.Html.CssSelect(".c-product__title").FirstOrDefault()?.InnerText
                                                    .Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");//c-product__title
                        string brand = PageResult1.Html.CssSelect(".c-product__title-container--brand-link").FirstOrDefault()?.InnerText
                                                    .Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");//
                        dic.Add("عنوان", title);
                        dic.Add("برند", brand);
                        dic.Add("رنگ", colors);
                        //dic.Add("json", json);
                        dic.Add("url", name);
                        var featuresLi = PageResult1.Html.CssSelect(".c-product__params").FirstOrDefault()?.SelectNodes("ul/li").ToList();//c-product__params 
                        if (featuresLi != null)
                        {
                            foreach (var c in featuresLi)
                            {
                                var exists = c.SelectSingleNode("button");
                                if (exists == null)
                                {
                                    var spans = c.SelectNodes("span").ToList();
                                    string spanKey = spans[0].InnerText.Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");
                                    string spanValue = spans[1].InnerText.Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");

                                    if (pairs.ContainsKey(spanValue))
                                    {
                                        spanValue = (string)pairs[spanValue];
                                    }
                                    dic.Add(spanKey, StaticValue.toEnglishNumber(spanValue));
                                }
                            }
                        }
                        var featuresImpLi = PageResult1.Html.CssSelect(".c-params__list").ToList();//?.SelectNodes("li").ToList();//tolist نیاز است
                        int jj = 1;
                        if (featuresImpLi != null)
                        {
                            foreach (var ul in featuresImpLi)
                            {
                                string master = "";
                                var li = ul.SelectNodes("li");
                                if (li != null)
                                {
                                    foreach (var c in li)
                                    {
                                        var temp1 = c.CssSelect(".c-params__list-key").FirstOrDefault();
                                        var temp = (temp1 != null) ? temp1.SelectSingleNode("span") : null;
                                        string divKey = ((temp == null) ? "" : temp.InnerText).Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");

                                        if (string.IsNullOrEmpty(divKey))
                                        {
                                            divKey = master + " " + jj;
                                            jj++;
                                        }

                                        master = divKey;

                                        if (!dic.ContainsKey(divKey))
                                        {


                                            string divValue = c.CssSelect(".c-params__list-value").FirstOrDefault()?.SelectSingleNode("span").InnerText.Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");
                                            if (pairs.ContainsKey(divValue))
                                            {
                                                divValue = (string)pairs[divValue];
                                            }
                                            dic.Add(divKey, StaticValue.toEnglishNumber(divValue));
                                        }
                                        //}
                                    }
                                }
                            }
                        }
                        string priceTemp = PageResult1.Html.CssSelect(".js-price-value").FirstOrDefault()?.InnerText
                                                       .Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");

                        var price = StaticValue.toEnglishNumber(priceTemp);
                        dic.Add("قیمت", price);


                        product.Add(dic);
                        if (dic.Count() > max)
                        {
                            max = dic.Count();
                            maxDic = dic;
                        }

                    }
                    catch (Exception ex)
                    {
                        System.Console.WriteLine(ex.Message);
                    }
                }
                System.Console.WriteLine(i + " " + DateTime.Now);

                i++;
                uri = $"{url}/?pageno={i}&sortby=4";
                PageResult = Browser.NavigateToPage(new Uri(uri));
                aTags = PageResult.Html.CssSelect(".js-product-item").ToList();


            }
            System.Console.WriteLine(DateTime.Now);
            string jsonString = JsonConvert.SerializeObject(product);

            // Write that JSON to txt file,  
            System.IO.File.WriteAllText(StaticValue.path + $"{name1}.json", jsonString);
            return jsonString;
        }

        public AnalysisProductsReturn AnalysisProducts(AnalysisProductsInput input)
        {
            List<AnalysisProductsByAttributesReturn> chartsData = new List<AnalysisProductsByAttributesReturn>();
            AnalysisProductsReturn output = new AnalysisProductsReturn();
            var productsJson = GetProductFromFile(new GetProductInput
            {
                groupProduct = input.groupProduct
            });
            var products = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(productsJson);
            var attributes = GetAttributeValues(new GetAttributeValuesInput
            {
                name = input.groupProduct.name,
                url = input.groupProduct.url
            });
            List<KeyValuePair<string, string>> attrByValuesPairs = new List<KeyValuePair<string, string>>();
            var product = JsonConvert.DeserializeObject<Dictionary<string, string>>(input.jsonProduct);
            foreach (var a in attributes)
            {
                if (a.name != "قیمت" && a.name != "امتیاز" && a.name != "عنوان")
                {
                    product.TryGetValue(a.displayTitle, out string value);
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        attrByValuesPairs.Add(new KeyValuePair<string, string>(a.displayTitle, value));
                    }
                }
            }
            foreach (var item in attrByValuesPairs)
            {
                var tempProduct = products;
                var attrTemp = attrByValuesPairs.Where(x => x.Key != item.Key);
                foreach (var p in attrTemp)
                {
                    tempProduct = tempProduct.Where(x => (x.TryGetValue(p.Key, out string v)? (string.IsNullOrEmpty( v)? "":v):"").Trim().Contains(p.Value.Trim())).ToList();
                }
                if (tempProduct.Any())
                {
                    AnalysisProductsByAttributesReturn tempAttrProductInfo = new AnalysisProductsByAttributesReturn();
                    tempAttrProductInfo.attributeName = item.Key;
                    tempAttrProductInfo.attrEvaluation = new List<AnalysisAttributeByPrice>();
                    foreach (var itm in tempProduct)
                    {

                        itm.TryGetValue(item.Key, out string value);
                        //if ((string.IsNullOrEmpty(value)?"":value).Trim() != item.Value.Trim())
                        //{

                            itm.TryGetValue("قیمت", out string price1);
                            tempAttrProductInfo.attrEvaluation.Add(new AnalysisAttributeByPrice
                            {
                                label = value,
                                value = long.Parse(price1.Replace(",", ""))
                            });
                        //}
                    }

                    chartsData.Add(tempAttrProductInfo);
                }
            }
            int numColors = products.Count();
            var colors = new List<string>();
            var random = new Random(); // Make sure this is out of the loop!
            for (int i = 0; i < numColors; i++)
            {
                colors.Add(String.Format("#{0:X6}", random.Next(0x1000000)));
            }
            output.colors = colors;
            output.name = input.name;
            output.attrEvaluation = chartsData;
            return output;
        }
    }
}
