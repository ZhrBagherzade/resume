﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.RecommederSystem.Dto
{
    public class GetProductReturn
    {
        public string name { get; set; }
        public string price { get; set; }
        public string url { get; set; }
        public string jsonProduct { get; set; }
    }
    public class ProductAndAttributes
    {
        public long fromPrice { get; set; } = 0;
        public long toPrice { get; set; } = 0;
        public long minPrice { get; set; } = 0;
        public long maxPrice { get; set; } = 0;
        public List<List<GetProductReturn>> products { get; set; }
        public List<GetAttributeValuesReturn> attributes { get; set; }
    }
}
