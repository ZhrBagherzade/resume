﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.RecommederSystem.Dto
{
    public class AnalysisProductsInput
    {
        public GetAttributeValuesInput groupProduct { get; set; }
        public string name { get; set; }
        public string price { get; set; }
        public string url { get; set; }
        public string jsonProduct { get; set; }
    }
}
