﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.RecommederSystem.Dto
{
   
    public class AnalysisProductsReturn
    {
        
        public List<AnalysisProductsByAttributesReturn> attrEvaluation { get; set; }
        public string name { get; set; }
        public List<string> colors { get; set; }
    }
    public class AnalysisProductsByAttributesReturn
    {
        //public List<AnalysisProductsByAttributs> productEvaluation { get; set; }
        public List<AnalysisAttributeByPrice> attrEvaluation { get; set; }
        public string attributeName { get; set; }
    }
    
    public class AnalysisAttributeByPrice
    {
        public string label { get; set; }
        public long value { get; set; }
    }

    public class AnalysisProductsByAttributs
    {
        public int id { get; set; }
        public string name { get; set; }
        public long price { get; set; }
        public string attrName { get; set; }
        public string attrValue { get; set; }
    }
}
