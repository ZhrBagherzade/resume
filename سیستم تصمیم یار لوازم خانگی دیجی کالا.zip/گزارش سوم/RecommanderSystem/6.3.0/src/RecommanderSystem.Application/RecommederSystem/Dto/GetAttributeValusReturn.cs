﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.RecommederSystem.Dto
{
    public class GetAttributeValuesReturn
    {
        public string displayTitle { get; set; }
        public string mainTitle { get; set; }
        public bool isPrice { get; set; } = false;
        public long price { get; set; } = 0;
        public string name { get; set; } = "";
        public long fromPrice { get; set; } = 0;
        public long toPrice { get; set; } = 0;
        public long minPrice { get; set; } = 0;
        public long maxPrice { get; set; } = 0;
        public List<GetSubAttributeValuesReturn> value { get; set; }
    }
    public class GetSubAttributeValuesReturn
    {
        public string name { get; set; }
        public string value { get; set; }
        public bool selected { get; set; }
    }
}

