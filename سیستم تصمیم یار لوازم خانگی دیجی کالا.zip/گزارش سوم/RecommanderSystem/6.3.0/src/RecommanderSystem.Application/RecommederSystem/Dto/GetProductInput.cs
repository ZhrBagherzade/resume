﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.RecommederSystem.Dto
{
    public class GetProductInput
    {
        public string name { get; set; }
        public List<GetAttributeValuesReturn> attr { get; set; }
        public string fromPrice { get; set; }
        public string toPrice { get; set; }
        public GetAttributeValuesInput groupProduct { get; set; }
    }
}
