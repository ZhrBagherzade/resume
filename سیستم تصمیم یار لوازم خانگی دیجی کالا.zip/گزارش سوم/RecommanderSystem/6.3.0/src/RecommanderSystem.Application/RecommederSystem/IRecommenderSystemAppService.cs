﻿using Abp.Application.Services;
using RecommanderSystem.RecommederSystem.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.RecommederSystem
{
    public interface IRecommenderSystemAppService:IApplicationService
    {
        //get Attribute and get Product and Service 2 Recommand

        //List<GetAttributeValuesReturn> GetAttributeValues(GetAttributeValuesInput input);
        ProductAndAttributes GetProduct(GetProductInput input);
        List<List<GetProductReturn>> GetProductsWithConditions(GetProductInput input);
        AnalysisProductsReturn AnalysisProducts(AnalysisProductsInput input);

    }
}
