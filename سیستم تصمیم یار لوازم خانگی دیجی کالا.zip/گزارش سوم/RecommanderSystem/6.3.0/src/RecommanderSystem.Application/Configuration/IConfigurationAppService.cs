﻿using System.Threading.Tasks;
using Abp.Application.Services;
using RecommanderSystem.Configuration.Dto;

namespace RecommanderSystem.Configuration
{
    public interface IConfigurationAppService: IApplicationService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}