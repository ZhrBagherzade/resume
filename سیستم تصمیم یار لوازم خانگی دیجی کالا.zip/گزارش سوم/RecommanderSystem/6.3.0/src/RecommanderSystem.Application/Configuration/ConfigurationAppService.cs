﻿using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Runtime.Session;
using RecommanderSystem.Configuration.Dto;

namespace RecommanderSystem.Configuration
{
    [AbpAuthorize]
    public class ConfigurationAppService : RecommanderSystemAppServiceBase, IConfigurationAppService
    {
        public async Task ChangeUiTheme(ChangeUiThemeInput input)
        {
            await SettingManager.ChangeSettingForUserAsync(AbpSession.ToUserIdentifier(), AppSettingNames.UiTheme, input.Theme);
        }
    }
}
