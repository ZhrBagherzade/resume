﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.Menu.Dto
{
    public class LoadMenuReturn
    {
        public string key { get; set; }
        public List<SubMenu> subMenus { get; set; }
    }

    public class SubMenu
    {
        public string key { get; set; }
        public string href { get; set; }
    }
}
