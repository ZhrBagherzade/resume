﻿using Abp.Application.Services;
using RecommanderSystem.Menu.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.Menu
{
    public interface IMenuAppService: IApplicationService
    {
        List<LoadMenuReturn> LoadMenuService();
    }
}
