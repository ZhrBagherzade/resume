﻿using HtmlAgilityPack;
using Newtonsoft.Json;
using RecommanderSystem.Menu.Dto;
using RecommanderSystem.StaticValues;
using ScrapySharp.Extensions;
using ScrapySharp.Network;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RecommanderSystem.Menu
{
    public class MenuAppService: RecommanderSystemAppServiceBase, IMenuAppService
    {
        // getSidBarMenu();

       

        private static Dictionary<string, Dictionary<string, string>> getSidBarMenu()
        {
            ScrapingBrowser Browser = new ScrapingBrowser();
            Browser.AllowAutoRedirect = true; // Browser has many settings you can access in setup
            Browser.AllowMetaRedirect = true;
            Browser.AutoDetectCharsetEncoding = false;
            Browser.Encoding = Encoding.UTF8;
            //go to the home page
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            string uri = $"https://www.digikala.com/main/home-and-kitchen/";
            WebPage PageResult = Browser.NavigateToPage(new Uri(uri));

            Dictionary<string, Dictionary<string, string>> menu = new Dictionary<string, Dictionary<string, string>>();

            HtmlNode allRightSideBar = PageResult.Html.CssSelect(".c-box").FirstOrDefault();

            List<HtmlNode> allCategrories = allRightSideBar.SelectNodes("div/ul/li").ToList();

            foreach (var li in allCategrories)
            {
                Dictionary<string, string> subCategories = new Dictionary<string, string>();
                var subMenu = li.SelectNodes("ul/li/a").ToList();
                foreach (var s in subMenu)
                {
                    string text = s.InnerText.Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");
                    string href = s.Attributes.First(y => y.Name == "href").Value.Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");

                    subCategories.Add(text, href);
                }
                var a = li.SelectSingleNode("a");
                string header = a.InnerText.Replace("\n", "").Replace("\r", "").TrimEnd().TrimStart().Replace("ی", "ي").Replace("ک", "ك");
                menu.Add(header, subCategories);
            }
            System.Console.WriteLine(DateTime.Now);
            string jsonString = JsonConvert.SerializeObject(menu);

            // Write that JSON to txt file,  
            System.IO.File.WriteAllText(StaticValue.path + "menu.json", jsonString);
            System.Console.WriteLine(DateTime.Now);
            return menu;
        }

       
        public List<LoadMenuReturn> LoadMenuService()
        {

            if (StaticValue.Menu == null)
            {
                if (File.Exists(StaticValue.path + "menu.json"))
                {
                    string json = File.ReadAllText(StaticValue.path + "menu.json");

                    StaticValue.Menu = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(json);
                }
                else
                {
                    StaticValue.Menu = getSidBarMenu();
                }
            }
            List<LoadMenuReturn> output = new List<LoadMenuReturn>();
            foreach (var itm in StaticValue.Menu)
            {
                List<SubMenu> childMenu = new List<SubMenu>();
                foreach(var subItm in itm.Value)
                {
                    childMenu.Add(new SubMenu
                    {
                        key = subItm.Key,
                        href = subItm.Value
                    });
                }
                output.Add(new LoadMenuReturn
                {
                    key = itm.Key,
                    subMenus = childMenu
                });
            }

            return output;

        }
    }
}
