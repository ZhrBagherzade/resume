﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using RecommanderSystem.MultiTenancy.Dto;

namespace RecommanderSystem.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}
