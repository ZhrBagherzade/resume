﻿using System.Threading.Tasks;
using Abp.Application.Services;
using RecommanderSystem.Sessions.Dto;

namespace RecommanderSystem.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}
