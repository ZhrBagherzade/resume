﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using RecommanderSystem.MultiTenancy;

namespace RecommanderSystem.Sessions.Dto
{
    [AutoMapFrom(typeof(Tenant))]
    public class TenantLoginInfoDto : EntityDto
    {
        public string TenancyName { get; set; }

        public string Name { get; set; }
    }
}