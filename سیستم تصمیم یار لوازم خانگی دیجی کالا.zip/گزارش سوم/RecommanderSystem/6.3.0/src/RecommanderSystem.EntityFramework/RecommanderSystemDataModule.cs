﻿using System.Data.Entity;
using System.Reflection;
using Abp.Modules;
using Abp.Zero.EntityFramework;
using RecommanderSystem.EntityFramework;

namespace RecommanderSystem
{
    [DependsOn(typeof(AbpZeroEntityFrameworkModule), typeof(RecommanderSystemCoreModule))]
    public class RecommanderSystemDataModule : AbpModule
    {
        public override void PreInitialize()
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<RecommanderSystemDbContext>());

            Configuration.DefaultNameOrConnectionString = "Default";
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(Assembly.GetExecutingAssembly());
        }
    }
}
