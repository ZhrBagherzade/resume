# Important

Issues of this repository are tracked on https://github.com/aspnetboilerplate/aspnetboilerplate. Please create your issues on https://github.com/aspnetboilerplate/aspnetboilerplate/issues.

ASP.NET Boilerplate - Module Zero - Startup Template
----------------------------------------------------

This project is aimed to be a starter template for ABP and module zero.
You can create your project on http://www.aspnetboilerplate.com/Templates
